# This file transforms the raw data into usable input for PCVAR.

library('reshape2')

# loading the data
ezd	 <- read.csv('raw/ez_d.csv')
head(ezd)
dim(ezd)
tail(ezd)
mezd	 <- melt(ezd,id.vars=c(1,2,3))
save(mezd,file='mezd')

# preping the weights
ezw.tmp	 <- read.csv('raw/ez_w.csv')
head(ezw.tmp)
dim(ezw.tmp)
w	 <- ezw.tmp[,-1]
rownames(w)<-colnames(w)
# setting own weight to zero and normalizing rows to 1 
diag(w)	 <- 0
ezw	<-	w/rowSums(w)
save(ezw,file='ezw')

